//
//  student.swift
//  OnTheMap
//
//  Created by Najd  on 23/11/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation

class savedStudentInformation {
    
static var objectId = ""
static var uniqueKey = ""
static var firstName = ""
static var lastName = ""
static var mapString = ""
static var mediaURL = ""
static var latitude : Double = 0.0
static var longitude: Double = 0.0
static var createdAt = ""
static var updatedAt = ""
    
static var results: [sLocations] = []
    
}
