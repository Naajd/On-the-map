//
//  NewLocationViewController.swift
//  OnTheMap
//
//  Created by Najd  on 17/11/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class NewLocationViewController: UIViewController , MKMapViewDelegate{
    var studentInformation : studentInformation?

    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var NewLocationButton: UIButton!

    
    override func viewWillAppear(_ animated: Bool) {

        var annotations = [MKPointAnnotation]()
        let lat = CLLocationDegrees(studentInformation?.latitude ?? 0)
        let long = CLLocationDegrees(studentInformation?.longitude ?? 0)
        let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)

        let first = studentInformation?.firstName ?? ""
        let last = studentInformation?.lastName ?? ""
        let mediaURL = studentInformation?.mediaURL
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = "\(first) \(last)"
        annotation.subtitle = mediaURL 
        annotations.append(annotation)

       self.mapView.addAnnotation(annotation)
    }


    @IBAction func NewLocation(_ sender: Any) {
        
        let new = self.storyboard?.instantiateViewController(withIdentifier: "MapViewController")
        
        if savedStudentInformation.objectId != "" {
            API.getLocations{ (success , error) in
                if success {
                    self.Alert("submited ", "")
                    self.present(new!, animated: true, completion: nil)
                } else {
                    self.Alert("Error", error?.localizedDescription ?? "")
                }
            }
        } else {

            API.postLocation(mapString: (studentInformation?.mapString)! , mediaURL: (studentInformation?.mediaURL)!, latitude: (studentInformation?.latitude)!, longitude: (studentInformation?.longitude)!){ (error) in
                if error != nil  {
                    self.Alert("there is a location already ", "")
                    self.present(new!, animated: true,completion: nil)
                }  else {
                    self.Alert("Error", error?.localizedDescription ?? "!")
                }
            }
        }
 }
    
    @IBAction func cancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}


