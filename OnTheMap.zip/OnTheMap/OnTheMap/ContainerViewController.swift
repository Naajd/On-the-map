//
//  ContainerViewController.swift
//  OnTheMap
//
//  Created by Najd  on 20/10/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class ContainerViewController: UIViewController{
    
/*    override func viewDidLoad(){
        super.viewDidLoad()
        
        setupUI()
        loadStudentLocations()
    }
    
    func setupUI(){
        let plusButton = UIBarButtonItem(barButtonSystemItem: add, target: self, action: #selector(self.addLocationTapped(_:)))

        let refrehButton = UIBarButtonItem(barButtonSystemItem: refresh, target: self, action: #selector(self.refreshLocationTapped(_:)))
        
        let logoutButton = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(self.logoutTapped(_:)))
        
        navigationItem.rightBarButtonItem = (plusButton, refrehButton)
        navigationItem.leftBarButtonIte = logoutButton
    }
   
    @objc private func addLocationTapped(_ sender: Any){
        let addVC = self.storyboard?.instantiateViewController(withIdentifier: "AddLocationNavigationController") as! UINavigationController
        
        present(navController, animated: true, completion: nil)
    }
    
    @objc private func refrehLocationTapped(_ sender: Any){
        
        loadStudentLocations()
    }
    
    @objc private func logoutTapped(_ sender: Any){
    let alertController = UIAlertController(title: "Logout", message: "Are you sure you want to logout?", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Logout", style: .destructive, handler: {(_ )in
            API.deleteSession{(err) in
                guard err == nill else{
                    self.showAlert(title:"Eror", message: err!)
                    return
                }
                self.dismiss(animated: true, completion: nil)
            }
        }))
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    private func loadStudentLocations(){
        let ai = startAnActivityIndicator()
        API.parser.getStudentLocations{ (data) in
            ai.stopAnimating()
            guard let data= data else{
                self.showAlert(title: "Eror", massage:"No internet coniction")
                return
            }
            gurad data.count>0 else {
                self.showAlert(title: "Eror", massage:"No internet coniction")
return            }
        }
      self.reloadLocations()
    }
    
}
}
*/
