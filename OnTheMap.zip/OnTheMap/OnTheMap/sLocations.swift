//
//  Locations.swift
//  OnTheMap
//
//  Created by Najd  on 17/11/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
struct sLocations : Codable{
   
    var objectId = ""
    var uniqueKey = ""
    var firstName = ""
    var lastName = ""
    var mapString = ""
    var mediaURL = ""
    var latitude : Double = 0.0
    var longitude: Double = 0.0
    var createdAt = ""
    var updatedAt = "" 
    var results :[studentInformation]?
    
   // let decoder = JSONDecoder()
   // let encoder = JSONEncoder()
   //  public init(from decoder: Decoder) throws{}
   //  public init(from encoder: Encoder) throws{}

}
