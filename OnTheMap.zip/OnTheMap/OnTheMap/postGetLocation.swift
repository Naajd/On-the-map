//
//  postGetLocation.swift
//  OnTheMap
//
//  Created by Najd  on 19/11/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
import UIKit



func postLoc(completion:@escaping (Bool,Error?)->()) {
 
    let parseAppId = "QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr"
    let restApiKey =  "QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY"
    

    let postLoc = "{ \"uniqueKey\": \"\(StudentInformation.uniqueKey)\", \"firstName\": \"\(StudentInformation.firstName)\", \"lastName\": \"\(StudentInformation.lastName)\", \"mapString\": \"\(StudentInformation.mapString)\", \"mediaURL\": \"\(StudentInformation.mediaURL)\", \"latitude\": \(StudentInformation.latitude), \"longitude\": \(StudentInformation.longitude) } "
    
    let session = URLSession.shared
    let task = session.dataTask(with: parseAppId) { data, response, error in
        if error != nil {
            completion(error)
            
            return
        }
        print(String(data: data!, encoding: .utf8)!)
        completion(nil)
    }
    task.resume()
}

