//
//  kyes.swift
//  OnTheMap
//
//  Created by Najd  on 19/11/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//


import Foundation

struct Kyes: Codable {
    
    let udacity: [String:String]
    let username: String
    let password: String
}

