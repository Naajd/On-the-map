//
//  postInfo.swift
//  OnTheMap
//
//  Created by Najd  on 19/11/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation


struct PostStudentLocationRequst : Codable {
    let uniqueKey:String
    let firstName:String
    let lastName:String
    let mapString:String
    let mediaURL:String
    let latitude:Double
    let longitude:Double
    
}
